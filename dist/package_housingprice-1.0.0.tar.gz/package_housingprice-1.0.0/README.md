# mle-training
Assignment 1.2
